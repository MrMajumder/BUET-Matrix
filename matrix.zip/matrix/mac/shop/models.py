from django.db import models

# Create your models here.
class Product(models.Model):
    product_id = models.AutoField
    product_name = models.CharField(max_length=50)
    category = models.CharField(max_length=50, default="")
    subcategory = models.CharField(max_length=50, default="")
    price = models.IntegerField(default=0)
    desc = models.CharField(max_length=300)
    pub_date = models.DateField()
    image = models.ImageField(upload_to='shop/images', default="")

    def __str__(self):
        return self.product_name


class Contact(models.Model):
    msg_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=70, default="")
    phone = models.CharField(max_length=70, default="")
    desc = models.CharField(max_length=500, default="")


    def __str__(self):
        return self.name

class vendor_product_details(models.Model):
    sale_request_id = models.AutoField(primary_key=True)
    Vendor_Name = models.CharField(max_length=50, default="")
    Vendor_Email = models.CharField(max_length=70, default="")
    Product_Name = models.CharField(max_length=70, default="")
    Product_Quantity = models.IntegerField(default=0)
    Product_Quality = models.CharField(max_length=500, default="")
    Estimated_Delivery_Date = models.CharField(max_length=70, default="")
    Production_Cost = models.CharField(max_length=20, default="")
    Product_Return_Policy = models.CharField(max_length=500, default="")
    desc = models.CharField(max_length=500, default="")

    def __str__(self):
        return self.Vendor_Name
